# nodebb

This is a simple node.js application showing how to combine:

- Promises A+ (bluebird)
- Express.js 4
- Sequelize 2
- Require.js 2
- Backbone
- Bootstrap 3

